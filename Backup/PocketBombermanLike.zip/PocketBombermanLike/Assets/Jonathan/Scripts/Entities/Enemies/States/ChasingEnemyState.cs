public enum ChasingEnemyState
{
    Patrolling,
    Chasing,
    Exhausted
}