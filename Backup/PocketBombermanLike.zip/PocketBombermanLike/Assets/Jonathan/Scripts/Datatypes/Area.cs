using System;
using UnityEngine;

[Serializable]
public struct Area
{
    public float Height;
    public float Width;
}